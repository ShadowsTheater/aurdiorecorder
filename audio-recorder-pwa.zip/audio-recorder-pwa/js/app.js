/**
 * Audio Recorder PWA
 * Captura áudio do sistema/tab via getDisplayMedia + MediaRecorder
 * Funciona melhor no Chrome/Edge desktop (Windows).
 * No Android o suporte a áudio interno via web é limitado.
 */

(() => {
  'use strict';

  // ========== DOM ==========
  const $ = (sel) => document.querySelector(sel);
  const statusText = $('#status-text');
  const timerEl = $('#timer');
  const btnRecord = $('#btn-record');
  const btnStop = $('#btn-stop');
  const visualizer = $('#visualizer');
  const recordingsList = $('#recordings-list');
  const toastEl = $('#toast');
  const installBanner = $('#install-banner');
  const infoBox = $('#info-box');

  // ========== State ==========
  let mediaRecorder = null;
  let recordedChunks = [];
  let stream = null;
  let audioContext = null;
  let analyser = null;
  let animationId = null;
  let startTime = 0;
  let timerInterval = null;
  let isRecording = false;
  let deferredPrompt = null;

  // ========== Helpers ==========
  function showToast(msg, duration = 3000) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    setTimeout(() => toastEl.classList.remove('show'), duration);
  }

  function formatTime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const m = String(Math.floor(totalSec / 60)).padStart(2, '0');
    const s = String(totalSec % 60).padStart(2, '0');
    return `${m}:${s}`;
  }

  function updateStatus(text, className = '') {
    statusText.textContent = text;
    statusText.className = 'status-text ' + className;
  }

  function createBars() {
    visualizer.innerHTML = '';
    for (let i = 0; i < 32; i++) {
      const bar = document.createElement('div');
      bar.className = 'bar';
      bar.style.height = '4px';
      visualizer.appendChild(bar);
    }
  }

  function animateVisualizer() {
    if (!analyser) return;
    const bars = visualizer.querySelectorAll('.bar');
    const data = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(data);

    bars.forEach((bar, i) => {
      const value = data[i * 2] || 0;
      const height = Math.max(4, (value / 255) * 70);
      bar.style.height = height + 'px';
    });

    animationId = requestAnimationFrame(animateVisualizer);
  }

  function stopVisualizer() {
    if (animationId) {
      cancelAnimationFrame(animationId);
      animationId = null;
    }
    visualizer.querySelectorAll('.bar').forEach((b) => (b.style.height = '4px'));
  }

  // ========== Core Recording ==========
  async function startRecording() {
    if (isRecording) return;

    try {
      // getDisplayMedia exige video:true na maioria dos browsers
      // systemAudio: "include" ajuda no Chrome desktop (Windows)
      const constraints = {
        video: {
          width: { ideal: 1 },
          height: { ideal: 1 },
          frameRate: { ideal: 1 }
        },
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false
        },
        // Chrome-specific hints
        systemAudio: 'include',
        selfBrowserSurface: 'include',
        preferCurrentTab: false
      };

      stream = await navigator.mediaDevices.getDisplayMedia(constraints);

      // Verificar se veio áudio
      const audioTracks = stream.getAudioTracks();
      if (audioTracks.length === 0) {
        stream.getTracks().forEach((t) => t.stop());
        showToast('Nenhum áudio capturado. Selecione a opção de compartilhar áudio na janela do sistema.');
        updateStatus('Sem áudio — tente novamente', '');
        return;
      }

      // Para o vídeo (não precisamos dele)
      stream.getVideoTracks().forEach((t) => {
        t.enabled = false;
        // Não paramos para manter a sessão de captura
      });

      // Setup Web Audio para visualizer
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContext.createMediaStreamSource(stream);
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 128;
      source.connect(analyser);

      // MediaRecorder
      const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : 'audio/ogg';

      recordedChunks = [];
      mediaRecorder = new MediaRecorder(stream, {
        mimeType,
        audioBitsPerSecond: 128000
      });

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) recordedChunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: mediaRecorder.mimeType });
        addRecording(blob);
        cleanup();
      };

      mediaRecorder.onerror = (e) => {
        console.error('MediaRecorder error:', e);
        showToast('Erro na gravação');
        stopRecording();
      };

      // Quando o usuário para o compartilhamento pelo browser
      stream.getAudioTracks()[0].onended = () => {
        if (isRecording) stopRecording();
      };

      mediaRecorder.start(1000); // timeslice 1s
      isRecording = true;
      startTime = Date.now();

      // UI
      btnRecord.classList.add('recording');
      btnRecord.querySelector('.rec-icon').style.borderRadius = '6px';
      btnStop.disabled = false;
      updateStatus('Gravando…', 'recording');
      timerInterval = setInterval(() => {
        timerEl.textContent = formatTime(Date.now() - startTime);
      }, 200);

      createBars();
      animateVisualizer();
      showToast('Gravação iniciada!');
    } catch (err) {
      console.error(err);
      if (err.name === 'NotAllowedError') {
        showToast('Permissão negada. Você precisa permitir o compartilhamento de tela/áudio.');
      } else if (err.name === 'NotSupportedError') {
        showToast('Seu navegador não suporta captura de áudio do sistema.');
      } else {
        showToast('Erro: ' + (err.message || 'Não foi possível iniciar'));
      }
      updateStatus('Pronto para gravar', 'ready');
      cleanup();
    }
  }

  function stopRecording() {
    if (!isRecording || !mediaRecorder) return;

    if (mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
    isRecording = false;

    // UI
    btnRecord.classList.remove('recording');
    btnRecord.querySelector('.rec-icon').style.borderRadius = '50%';
    btnStop.disabled = true;
    updateStatus('Processando…', '');
    clearInterval(timerInterval);
    stopVisualizer();
  }

  function cleanup() {
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
      stream = null;
    }
    if (audioContext) {
      audioContext.close().catch(() => {});
      audioContext = null;
      analyser = null;
    }
    mediaRecorder = null;
    updateStatus('Pronto para gravar', 'ready');
  }

  function addRecording(blob) {
    const url = URL.createObjectURL(blob);
    const now = new Date();
    const name = `gravacao-${now.toISOString().slice(0, 19).replace(/[:T]/g, '-')}.webm`;
    const sizeKB = Math.round(blob.size / 1024);

    const item = document.createElement('div');
    item.className = 'recording-item';
    item.innerHTML = `
      <audio controls src="${url}"></audio>
      <span class="meta">${sizeKB} KB</span>
      <a class="btn-icon" href="${url}" download="${name}" title="Baixar" style="text-decoration:none;color:inherit;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
        </svg>
      </a>
      <button class="btn-icon" title="Excluir" aria-label="Excluir">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
        </svg>
      </button>
    `;

    const delBtn = item.querySelector('button');
    delBtn.addEventListener('click', () => {
      URL.revokeObjectURL(url);
      item.remove();
      if (!recordingsList.children.length) {
        recordingsList.parentElement.style.display = 'none';
      }
    });

    recordingsList.prepend(item);
    recordingsList.parentElement.style.display = 'block';
    showToast('Gravação salva! Você pode baixar o arquivo.');
    timerEl.textContent = '00:00';
  }

  // ========== Event listeners ==========
  btnRecord.addEventListener('click', () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  });

  btnStop.addEventListener('click', stopRecording);

  // Install prompt (PWA)
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBanner.classList.add('show');
  });

  installBanner.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      showToast('App instalado!');
    }
    deferredPrompt = null;
    installBanner.classList.remove('show');
  });

  // Detectar suporte
  function checkSupport() {
    const hasDisplayMedia = !!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia);
    const hasMediaRecorder = typeof MediaRecorder !== 'undefined';

    if (!hasDisplayMedia || !hasMediaRecorder) {
      updateStatus('Navegador não suportado', '');
      btnRecord.disabled = true;
      infoBox.innerHTML = `
        <strong>Seu navegador não suporta captura de áudio do sistema.</strong>
        <p>Recomendamos usar o Google Chrome ou Microsoft Edge no desktop (Windows funciona melhor).</p>
      `;
      return;
    }

    // Aviso específico para mobile
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
    if (isMobile) {
      infoBox.innerHTML = `
        <strong>Aviso no celular</strong>
        <ul>
          <li>No Android o suporte a áudio interno via navegador é <em>limitado</em>.</li>
          <li>Você precisará compartilhar a tela (ou a aba) e marcar a opção de áudio.</li>
          <li>Em muitos aparelhos só captura o áudio da aba do navegador, não de outros apps.</li>
          <li>Para captura total do sistema, um app nativo ainda é superior.</li>
        </ul>
      `;
    }
  }

  // Service Worker registration
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('./sw.js')
        .then((reg) => {
          console.log('[App] SW registrado:', reg.scope);
          // Checa atualizações
          reg.addEventListener('updatefound', () => {
            const newWorker = reg.installing;
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                showToast('Nova versão disponível. Recarregue a página.');
              }
            });
          });
        })
        .catch((err) => console.warn('[App] SW falhou:', err));
    });
  }

  // Init
  createBars();
  checkSupport();
  updateStatus('Pronto para gravar', 'ready');
})();
