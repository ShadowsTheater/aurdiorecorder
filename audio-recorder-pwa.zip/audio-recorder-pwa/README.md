# Audio Recorder PWA

Aplicativo Progressive Web App para gravar o áudio que está tocando no dispositivo (áudio interno / system audio) em tempo real.

Pronto para:
- Hospedar no **GitHub Pages**
- Empacotar com **PWABuilder** (Android TWA, Windows, etc.)

## ⚠️ Importante sobre captura de áudio

| Ambiente | Suporte a áudio interno |
|----------|-------------------------|
| Chrome / Edge **Windows** (desktop) | Bom (system audio + tab audio) |
| Chrome **macOS / Linux** | Principalmente áudio da aba |
| Chrome **Android** | Limitado – normalmente só áudio da aba do navegador |
| Safari / iOS | Muito restrito |

No celular Android a API web (`getDisplayMedia`) **não** tem o mesmo poder de um app nativo. O usuário precisa compartilhar a tela/aba e marcar “compartilhar áudio”.

## Estrutura do projeto

```
audio-recorder-pwa/
├── index.html
├── offline.html
├── manifest.webmanifest   ← completo (ícones, screenshots, shortcuts…)
├── sw.js                  ← service worker completo
├── browserconfig.xml
├── css/styles.css
├── js/app.js
├── icons/                 ← 16, 32, 72…512 + maskable + apple-touch
├── screenshots/
└── README.md
```

## Como publicar no GitHub Pages

1. Crie um repositório (ex: `audio-recorder-pwa`).
2. Faça upload de **todos** os arquivos desta pasta (mantenha a estrutura).
3. Vá em **Settings → Pages**.
4. Source: Deploy from a branch → `main` / root (ou `/docs` se preferir).
5. Aguarde alguns minutos e acesse:
   `https://SEU-USUARIO.github.io/audio-recorder-pwa/`

> **Importante**: o `start_url` e o `scope` do manifest estão relativos (`./`).  
> Funciona tanto na raiz quanto em subpasta do GitHub Pages.

## Como usar no PWABuilder

1. Acesse [https://www.pwabuilder.com](https://www.pwabuilder.com)
2. Cole a URL pública do seu GitHub Pages.
3. O PWABuilder vai analisar o manifest e o service worker.
4. Gere o pacote **Android** (TWA) ou **Windows**.
5. Baixe o `.aab` / `.apk` e publique na Play Store (ou teste diretamente).

### Checklist que o PWABuilder gosta

- [x] Manifest com `name`, `short_name`, `start_url`, `display`, `icons` (192 + 512)
- [x] Ícones **maskable**
- [x] Screenshots (`form_factor` narrow + wide)
- [x] Service Worker com `fetch` handler + precache
- [x] HTTPS (GitHub Pages já fornece)
- [x] `theme_color` e `background_color`
- [x] Meta tags Apple + favicon

## Testar localmente

```bash
# Qualquer servidor estático
npx serve .
# ou
python3 -m http.server 8080
```

Abra `http://localhost:8080` no Chrome.

## Licença

MIT – use como quiser.
